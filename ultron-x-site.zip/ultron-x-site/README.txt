ULTRON-X website starter

This folder contains index.html, the website file.

To publish it free using GitHub Pages:
1. Sign in to https://github.com in your browser.
2. Create a new PUBLIC repository named ultron-x.
3. In the repository choose Add file > Upload files.
4. Upload index.html from this folder (do not upload it as ultron-x.html; it must be named index.html).
5. Commit the upload.
6. Open Settings > Pages.
7. Under Build and deployment, choose Deploy from a branch; choose main and /(root), then Save.
8. Wait a few minutes. GitHub Pages will show the published website address in Settings > Pages.
9. Open that address in Chrome on Android. Tap the three-dot menu > Add to Home screen.

Notes:
- This starter is a front-end demo. Its simple built-in responses are not a connected AI model.
- Browser speech recognition depends on browser/device support and may require internet access.
- Do not put private API keys in index.html.
